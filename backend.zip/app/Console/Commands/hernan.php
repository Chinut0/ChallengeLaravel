<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Kreait\Firebase\JWT\Error\IdTokenVerificationFailed;
use Kreait\Firebase\JWT\IdTokenVerifier;

class hernan extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'hernan:prueba';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        $projectId = 'challenge-daf61';
        $idToken = "eyJhbGciOiJSUzI1NiIsImtpZCI6ImFlMDVlZmMyNTM2YjJjZTdjNTExZjRiMTcyN2I4NTkyYTc5ZWJiN2UiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vY2hhbGxlbmdlLWRhZjYxIiwiYXVkIjoiY2hhbGxlbmdlLWRhZjYxIiwiYXV0aF90aW1lIjoxNjI4ODk3NDg1LCJ1c2VyX2lkIjoiYXVyQnQ5cHN6Z2J0MUtjak9uZ2JBWVRpaGJuMiIsInN1YiI6ImF1ckJ0OXBzemdidDFLY2pPbmdiQVlUaWhibjIiLCJpYXQiOjE2Mjg4OTc0ODYsImV4cCI6MTYyODkwMTA4NiwiZW1haWwiOiJoZXJuYW4uY2FwYW5lZ3JhQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJoZXJuYW4uY2FwYW5lZ3JhQGdtYWlsLmNvbSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.RrX_GMQhvNevb1HXwVKuAiVTgnUDPH191DL0dOychBiDXz9XUBTc99PPj7mNNDJNfRFeNuz9MC62wRdWlL5Q47nw6dvd2fAx0fJrJ2qSXcnRcueV00F0IQfGXhWbxZ1xxs-Ah_GgxX0BvMx4rZj48gMvS9ypA2yv5u7rSUrzx_ad94CPy2X20Z5vQ-GvB-sVTgxAL5Sscqm0JcjhutdfK5Y6jxurVO5J42783b7MdvL1V-c96jMWrTIGVS4MRKwWoXnbO7LVoBmOUI3HQb0rMMtVbqRRjjHwU-SQziaHlThmwzahVq4Dvh7sunaUC5ASy2I8wtPoi3p1d3uXUiZZ7A";

        $verifier = IdTokenVerifier::createWithProjectId($projectId);

        try {
            $token = $verifier->verifyIdToken($idToken);
            $payload = $token->payload();
            $user = $payload['user_id'];
            dump($payload);
        } catch (IdTokenVerificationFailed $e) {
            echo $e->getMessage();
            // Example Output:
            // The value 'eyJhb...' is not a verified ID token:
            // - The token is expired.
            exit;
        }

        try {
            $token = $verifier->verifyIdTokenWithLeeway($idToken, $leewayInSeconds = 10000000);
        } catch (IdTokenVerificationFailed $e) {
            print $e->getMessage();
            exit;
        }
    }
}
